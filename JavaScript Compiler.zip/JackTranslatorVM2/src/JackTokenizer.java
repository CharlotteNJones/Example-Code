import java.util.ArrayList;

public class JackTokenizer {

	public ArrayList<String> translate(ArrayList<String> input) {
		ArrayList<String> output = new ArrayList<String>();

		output.addAll(removeComments(input));

		output = breakUp(output);

		output = tokenize(output);

		return output;

	}

	private ArrayList<String> tokenize(ArrayList<String> input) {
		ArrayList<String> output = new ArrayList<String>();

		output.add("<tokens>");

		for (String element : input) {
			if (element.length() != 0) {
				if (isKeyword(element)) {
					output.add("<keyword> " + element + " </keyword>");
				} else if (isSymbol(element.charAt(0))) {

					if (element.equals("<")) {
						output.add("<symbol> " + "&lt;" + " </symbol>");
					} else if (element.equals(">")) {
						output.add("<symbol> " + "&gt;" + " </symbol>");
					} else if (element.equals("&")) {
						output.add("<symbol> " + "&amp;" + " </symbol>");
					} else {
						output.add("<symbol> " + element + " </symbol>");
					}
				} else if (isInt(element)) {
					output.add("<integerConstant> " + element + " </integerConstant>");
				} else if (isString(element)) {
					String toAdd = element.substring(1, element.length() - 1);

					output.add("<stringConstant> " + toAdd + " </stringConstant>");
				} else {
					output.add("<identifier> " + element + " </identifier>");
				}
			}
		}

		output.add("</tokens>");

		return output;

	}

	private ArrayList<String> breakUp(ArrayList<String> input) {
		ArrayList<String> output = new ArrayList<String>();

		for (String line : input) {
			String element = "";

			boolean isString = false;

			for (int i = 0; i < line.length(); i++) {

				if (line.charAt(i) == '"') {
					if (isString) {
						element = "\"" + element + "\"";
					}
					output.add(element);
					element = "";
					isString = !isString;
				}

				if ((line.charAt(i) == ' ')) {
					if (!isString) {

						output.add(element);
						element = "";
					} else {
						element += line.charAt(i);
					}
				} else if (isSymbol(line.charAt(i))) {
					if (!isString) {
						output.add(element);
						element = "";
						output.add(Character.toString(line.charAt(i)));
					}
				} else {
					if (line.charAt(i) != '"') {
						element += line.charAt(i);
					}
				}

			}

			output.add(element);

		}

		return output;
	}

	private ArrayList<String> removeComments(ArrayList<String> input) {
		ArrayList<String> output = new ArrayList<String>();

		for (String line : input) {
			String trimmedLine = line.trim();
			String cleanLine = "";
			int i = 0;

			if (trimmedLine.length() > 0) {

				while (i < trimmedLine.length()) {
					if (i < trimmedLine.length() - 1) {
						if ((trimmedLine.charAt(i) == '/'
								&& (trimmedLine.charAt(i + 1) == '/' || trimmedLine.charAt(i + 1) == '*'))
								|| (trimmedLine.charAt(i) == '*' && i == 0)) {
							break;
						}
					}
					cleanLine = cleanLine + trimmedLine.charAt(i);
					i++;
				}

				output.add(cleanLine);
			}
		}

		return output;
	}

	private boolean isSymbol(char c) {
		return (c == '{' || c == '}' || c == '(' || c == ')' || c == '[' || c == ']' || c == '-' || c == ',' || c == ';'
				|| c == '+' || c == '-' || c == '*' || c == '/' || c == '&' || c == '|' || c == '<' || c == '>'
				|| c == '=' || c == '~' || c == '.');
	}

	private boolean isKeyword(String str) {
		return (str.equals("class") || str.equals("constructor") || str.equals("function") || str.equals("method")
				|| str.equals("field") || str.equals("static") || str.equals("var") || str.equals("int")
				|| str.equals("char") || str.equals("boolean") || str.equals("void") || str.equals("true")
				|| str.equals("false") || str.equals("null") || str.equals("this") || str.equals("let")
				|| str.equals("do") || str.equals("if") || str.equals("else") || str.equals("while")
				|| str.equals("return"));
	}

	private boolean isInt(String str) {
		return (str.charAt(0) == '0' || str.charAt(0) == '1' || str.charAt(0) == '2' || str.charAt(0) == '3'
				|| str.charAt(0) == '4' || str.charAt(0) == '5' || str.charAt(0) == '6' || str.charAt(0) == '7'
				|| str.charAt(0) == '8' || str.charAt(0) == '9');
	}

	private boolean isString(String str) {
		return (str.charAt(0) == '"' && str.charAt(str.length() - 1) == '"');
	}

}
