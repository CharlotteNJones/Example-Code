import java.util.ArrayList;

public class VMWriter {

	private ArrayList<String> output;
	private SymbolTable classTable;
	private SymbolTable subroutineTable;
	private String className;
	private int whileNum;
	private int ifNum;

	public ArrayList<String> writeVM(Node xml) {
		output = new ArrayList<>();
		classTable = new SymbolTable();
		subroutineTable = new SymbolTable();

		writeClassVM(xml);

		return output;
	}

	private String getMiddle(String line) {
		// System.out.println(tokens.get(currentToken));
		// System.out.println();
		String trimmedLine = line.trim();
		int start, end;
		int current = 0;

		if (!trimmedLine.contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			current++;
		}
		start = current + 1;

		current = trimmedLine.length() - 1;
		while (trimmedLine.charAt(current) != ' ') {
			current--;
		}
		end = current;

		return trimmedLine.substring(start, end);

	}

	private String getFirst(String line) {

		String trimmedLine = line.trim();
		String output = "";
		int current = 0;

		if (!trimmedLine.contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			output += trimmedLine.charAt(current);
			current++;
		}

		return output;
	}

	private void writeClassVM(Node xmlClass) {
		ArrayList<Object> content = xmlClass.getContent();

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("subroutineDec")) {
					writeSubroutineDecVM((Node) item);
				} else if (((Node) item).getType().equals("classVarDec")) {
					classTable.parseClassVarDec((Node) item);
				}
			} else if (getFirst((String) item).equals("<identifier>")) {
				className = getMiddle((String) item);
			}
		}
	}

	private void writeSubroutineDecVM(Node xmlSubroutineDec) {
		whileNum = 0;
		ifNum = 0;
		ArrayList<Object> content = xmlSubroutineDec.getContent();
		subroutineTable.clear();
		subroutineTable.parseSubroutineDec(xmlSubroutineDec);

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("subroutineBody")) {
					writeSubroutineBodyVM((Node) item);
				}
			} else {
				String xml = (String) item;

				if (getFirst(xml).equals("<identifier>")) {
					output.add("function " + className + "." + getMiddle(xml) + " "
							+ subroutineTable.varCount(VarKind.VAR));
				}

			}
		}

	}

	private void writeSubroutineBodyVM(Node xmlSubroutineBody) {
		ArrayList<Object> content = xmlSubroutineBody.getContent();

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("statements")) {
					writeStatementsVM((Node) item);
				}
			}
		}

	}

	private void writeStatementsVM(Node xmlStatements) {
		ArrayList<Object> content = xmlStatements.getContent();

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("doStatement")) {
					writeDoStatementVM((Node) item);
				} else if (((Node) item).getType().equals("returnStatement")) {
					writeReturnStatementVM((Node) item);
				} else if (((Node) item).getType().equals("letStatement")) {
					writeLetStatementVM((Node) item);
				} else if (((Node) item).getType().equals("whileStatement")) {
					writeWhileStatementVM((Node) item);
				} else if (((Node) item).getType().equals("ifStatement")) {
					writeIfStatementVM((Node) item);
				}
			}
		}
	}

	private void writeDoStatementVM(Node xmlDoStatement) {
		ArrayList<Object> content = xmlDoStatement.getContent();
		Node call = new Node(null, null);
		
		for (int i = 1; i < content.size() - 1; i++) {
			call.add(content.get(i));
		}
		writeSubroutineCallVM(call);
		output.add("pop temp 0");
		/*
		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("expressionList")) {
					writeExpressionListVM((Node) item);
					ArrayList<Object> listContent = ((Node) item).getContent();
					Node list = (Node) item;

					output.add(functionCall + " " + (listContent.size() - list.getAmountOf(",")));
					output.add("pop temp 0");

				}
			} else {
				String line = (String) item;
				if (!(getMiddle(line).equals("do") || getMiddle(line).equals("("))) {
					functionCall += getMiddle(line);
				}
			}
		}
		*/
	}

	private void writeReturnStatementVM(Node xmlReturnStatement) {
		ArrayList<Object> content = xmlReturnStatement.getContent();

		if (content.size() == 2) {
			output.add("push constant 0");
			output.add("return");
		} else {
			if (content.get(1) instanceof String) {
				String line = (String) content.get(1);
				String first = getFirst(line);
				String mid = getMiddle(line);

				if (first.equals("<integerConstant>")) {
					output.add("push constant " + mid);
				}

			} else {
				writeExpressionVM((Node) content.get(1));
			}
			output.add("return");
		}
	}

	private void writeLetStatementVM(Node xmlLetStatemet) {
		ArrayList<Object> content = xmlLetStatemet.getContent();
		if (!content.contains("<symbol> [ </symbol>")) {
			for (Object item : content) {
				if (item instanceof Node) {
					writeExpressionVM((Node) item);
				}
			}
			String name = getMiddle((String) content.get(1));
			popVar(name);
		} else {
			writeExpressionVM((Node) content.get(3));
			String name = getMiddle((String) content.get(1));
			pushVar(name);
			output.add("add");

			writeExpressionVM((Node) content.get(6));
			output.add("pop temp 0");
			output.add("pop pointer 1");
			output.add("push temp 0");
			output.add("pop that 0");

		}
	}

	private void writeWhileStatementVM(Node xmlWhileStatement) {
		ArrayList<Object> content = xmlWhileStatement.getContent();
		int num = whileNum;
		whileNum++;

		output.add("label WHILE_EXP" + num);

		writeExpressionVM((Node) content.get(2));
		output.add("not");
		output.add("if-goto WHILE_END" + num);

		writeStatementsVM((Node) content.get(5));

		output.add("goto WHILE_EXP" + num);
		output.add("label WHILE_END" + num);

		whileNum++;

	}

	private void writeIfStatementVM(Node xmlIfStatement) {
		ArrayList<Object> content = xmlIfStatement.getContent();
		int num = ifNum;
		ifNum++;

		if (content.size() > 7) {
			writeExpressionVM((Node) content.get(2));
			output.add("if-goto IF_TRUE" + num);
			output.add("goto IF_FALSE" + num);
			output.add("label IF_TRUE" + num);
			writeStatementsVM((Node) content.get(5));
			output.add("goto IF_END" + num);
			output.add("label IF_FALSE" + num);
			writeStatementsVM((Node) content.get(9));
			output.add("label IF_END" + num);
		} else {
			writeExpressionVM((Node) content.get(2));
			output.add("if-goto IF_TRUE" + num);
			output.add("goto IF_FALSE" + num);
			output.add("label IF_TRUE" + num);
			writeStatementsVM((Node) content.get(5));
			output.add("label IF_FALSE" + num);
		}
		ifNum++;
	}

	private void writeExpressionListVM(Node xmlExpressionList) {
		ArrayList<Object> content = xmlExpressionList.getContent();

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("expression")) {
					writeExpressionVM((Node) item);
				}
			}
		}
	}

	private void writeExpressionVM(Node xmlExpression) {
		ArrayList<Object> content = xmlExpression.getContent();
		ArrayList<String> operands = new ArrayList<>();

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("term")) {
					writeTermVM((Node) item);
				}
			} else {
				String line = (String) item;
				String mid = getMiddle(line);
				if (mid.equals("+") || mid.equals("-") || mid.equals("*") || mid.equals("/") || mid.equals("&lt;")
						|| mid.equals("|") || mid.equals("&amp;") || mid.equals("&gt;") || mid.equals("=")) {
					operands.add(mid);
				}

			}
		}

		for (String op : operands) {
			if (op.equals("+")) {
				output.add("add");
			} else if (op.equals("-")) {
				output.add("sub");
			} else if (op.equals("*")) {
				output.add("call Math.multiply 2");
			} else if (op.equals("/")) {
				output.add("call Math.divide 2");
			} else if (op.equals("&lt;")) {
				output.add("lt");
			} else if (op.equals("|")) {
				output.add("or");
			} else if (op.equals("&amp;")) {
				output.add("and");
			} else if (op.equalsIgnoreCase("&gt;")) {
				output.add("gt");
			} else if (op.equals("=")) {
				output.add("eq");
			}
		}

	}

	private void writeTermVM(Node xmlTerm) {
		ArrayList<Object> content = xmlTerm.getContent();

		String line = (String) content.get(0);
		String mid = getMiddle(line);
		String first = getFirst(line);

		if (content.size() == 1) {
			if (first.equals("<integerConstant>")) {
				output.add("push constant " + mid);
			} else if (first.equals("<identifier>")) {
				pushVar(mid);
			} else if (first.equals("<keyword>")) {
				if (mid.equals("true")) {
					output.add("push constant 0");
					output.add("not");
				} else if (mid.equals("false")) {
					output.add("push constant 0");
				} else if (mid.equals("null"))
					;
				{
					output.add("push constant 0");
				}
			} else if (first.equals("<stringConstant>")) {
				writeStringConstantVM(mid);
			}
		} else if (content.get(1) instanceof String) {
			String mid1 = getMiddle((String) content.get(1));
			if (mid1.equals("(") || mid1.equals(".")) {
				writeSubroutineCallVM(xmlTerm);
			} else if (mid1.equals("[")) {
				writeExpressionVM((Node) content.get(2));
				pushVar(mid);
				output.add("add");
				output.add("pop pointer 1");
				output.add("push that 0");
			}
		} else if (mid.equals("~") || mid.equals("-")) {
			writeTermVM((Node) content.get(1));

			if (mid.startsWith("~")) {
				output.add("not");
			} else {
				output.add("neg");
			}

		} else {
			writeExpressionVM((Node) content.get(1));
		}
	}

	private void writeSubroutineCallVM(Node xmlNode) {
		ArrayList<Object> content = xmlNode.getContent();
		String mid0 = getMiddle((String) content.get(0));
		String mid1 = getMiddle((String) content.get(1));
		Node list;

		if (mid1.equals("(")) {

			list = (Node) content.get(2);
			writeExpressionListVM(list);
			output.add("call " + className + "." + mid0 + " " + (list.getContent().size() - list.getAmountOf(",")));
			// output.add("pop temp 0");
		} else if (mid1.equals(".")) {
			
			String mid2 = getMiddle((String) content.get(2));
			list = (Node) content.get(4);
			writeExpressionListVM(list);
			if (subroutineTable.containsKey(mid0) || classTable.containsKey(mid0)) {
				pushVar(mid0);
				if (subroutineTable.containsKey(mid0)) {
					output.add("call " + subroutineTable.getType(mid0) + "." + mid2 + " " +(list.getContent().size() - list.getAmountOf(",") + 1));
				} else if (classTable.containsKey(mid0)) {
					output.add("call " + classTable.getType(mid0) + "." + mid2 + " " + (list.getContent().size() - list.getAmountOf(",") + 1));
				}
			} else {
				output.add("call " + mid0 + "." + mid2 + " " + (list.getContent().size() - list.getAmountOf(",")));
			}
		}
	}

	private void writeStringConstantVM(String str) {
		if (str.length() != 0) {
			output.add("push constant " + str.length());
			output.add("call String.new 1");
		}
		if (str.length() > 1) {
			for (int i = 0; i < str.length(); i++) {
				output.add("push constant " + ((int) str.charAt(i)));
				output.add("call String.appendChar 2");
			}
		}
	}

	private void pushVar(String var) {
		if (subroutineTable.containsKey(var)) {
			output.add(subroutineTable.getPush(var));
		} else {
			output.add(classTable.getPush(var));
		}
	}

	private void popVar(String var) {
		if (subroutineTable.containsKey(var)) {
			output.add(subroutineTable.getPop(var));
		} else {
			output.add(classTable.getPop(var));
		}
	}
}
