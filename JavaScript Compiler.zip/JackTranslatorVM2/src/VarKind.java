public enum VarKind {
	STATIC {
		public String toString() {
			return "";
		}
	}, FIELD {
		public String toString() {
			return "this";
		}
	}, ARG {
		public String toString() {
			return "argument";
		}
	}, VAR {
		public String toString() {
			return "local";
		}
	}, NONE {
		public String toString() {
			return "NONE";
		}
	};
	
	public abstract String toString();
}