import java.util.ArrayList;

public class CompilationEngine {

	private Node topNode;
	private Node currentNode;
	private int currentToken;
	private ArrayList<String> tokens;

	public Node translate(ArrayList<String> input) {
		topNode = new Node("class", null);
		currentNode = topNode;
		currentToken = 1;
		tokens = input;

		parseClass();

		return topNode;
	}

	private void add() {
		// if (currentToken < tokens.size() - 1) {
		currentNode.add(tokens.get(currentToken));
		currentToken++;
		// }
	}

	private String getMiddle() {
		// System.out.println(tokens.get(currentToken));
		// System.out.println();
		String trimmedLine = tokens.get(currentToken).trim();
		int start, end;
		int current = 0;

		if (!tokens.get(currentToken).contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			current++;
		}
		start = current + 1;

		current = trimmedLine.length() - 1;
		while (trimmedLine.charAt(current) != ' ') {
			current--;
		}
		end = current;

		return trimmedLine.substring(start, end);

	}

	private String getFirst() {

		String trimmedLine = tokens.get(currentToken).trim();
		String output = "";
		int current = 0;

		if (!tokens.get(currentToken).contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			output += trimmedLine.charAt(current);
			current++;
		}

		return output;
	}

	private String getNextMiddle() {
		// System.out.println(tokens.get(currentToken));
		// System.out.println();
		String trimmedLine = tokens.get(currentToken + 1).trim();
		int start, end;
		int current = 0;

		if (!tokens.get(currentToken).contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			current++;
		}
		start = current + 1;

		current = trimmedLine.length() - 1;
		while (trimmedLine.charAt(current) != ' ') {
			current--;
		}
		end = current;

		return trimmedLine.substring(start, end);

	}

	private void goToParent() {
		currentNode = currentNode.getParent();
	}

	private void newNode(String heading) {
		Node newNode = new Node(heading, currentNode);
		currentNode.add(newNode);
		currentNode = newNode;
	}

	private void parseClass() {

		while (!getMiddle().equals("}")) {
			if ((getMiddle().equals("constructor") || getMiddle().equals("function") || getMiddle().equals("method"))) {
				parseSubroutineDec();
			} else if (getMiddle().equals("static") || getMiddle().equals("field")) {
				parseClassVarDec();
			} else {
				add();
			}
		}
		add();

	}

	private void parseSubroutineDec() {
		newNode("subroutineDec");

		while (!getMiddle().equals("(")) {
			add();
		}
		add();
		parseParameterList();
		add();

		parseSubroutineBody();

		goToParent();
	}

	private void parseClassVarDec() {
		newNode("classVarDec");

		while (!getMiddle().equals(";")) {
			add();
		}
		add();

		goToParent();
	}

	private void parseParameterList() {
		newNode("parameterList");
		while (!getMiddle().equals(")")) {
			add();
		}
		goToParent();
	}

	private void parseSubroutineBody() {
		newNode("subroutineBody");

		add();

		while (getMiddle().equals("var")) {
			parseVarDec();
		}

		parseStatements();

		add();
		goToParent();
	}

	private void parseVarDec() {
		newNode("varDec");

		while (!getMiddle().equals(";")) {
			add();
		}
		add();
		goToParent();

	}

	private void parseStatements() {
		newNode("statements");

		while (!getMiddle().equals("}")) {
			if (getMiddle().equals("let")) {
				parseLetStatement();
			} else if (getMiddle().equals("while")) {
				parseWhileStatement();
			} else if (getMiddle().equals("do")) {
				parseDoStatement();
			} else if (getMiddle().equals("return")) {
				parseReturnStatement();
			} else if (getMiddle().equals("if")) {
				parseIfStatement();
			} else {
				add();
			}
		}
		goToParent();
	}

	private void parseLetStatement() {
		newNode("letStatement");

		while (!getMiddle().equals(";")) {

			add();

			if (getMiddle().equals("[")) {
				add();
				parseExpression();
				// add();
			}

			if (getMiddle().equals("=")) {
				add();
				parseExpression();
			}
		}

		add();

		goToParent();

	}

	private void parseWhileStatement() {
		newNode("whileStatement");

		add();
		add();
		parseExpression();
		add();
		add();
		parseStatements();
		add();

		goToParent();
	}

	private void parseDoStatement() {
		newNode("doStatement");

		while (!getMiddle().equals(";")) {
			if (getMiddle().equals("(")) {
				add();
				parseExpressionList();
			} else {
				add();
			}

		}
		add();
		goToParent();
	}

	private void parseReturnStatement() {
		newNode("returnStatement");
		add();
		if (getFirst().equals("<identifier>") || getFirst().equals("<keyword>")) {
			parseExpression();
			add();
		} else {
			while (!getMiddle().equals(";")) {
				add();
			}
			add();
		}
		goToParent();
	}

	private void parseIfStatement() {
		newNode("ifStatement");
		add();
		add();
		parseExpression();
		add();
		add();
		parseStatements();
		add();
		if (getMiddle().equals("else")) {
			add();
			add();
			parseStatements();
			add();
		}
		goToParent();
	}

	private void parseExpression() {
		newNode("expression");

		while (getFirst().equals("<integerConstant>") || getFirst().equals("<stringConstant>")
				|| getFirst().equals("<keyword>") || getFirst().equals("<identifier>") || getMiddle().equals("(")
				|| getMiddle().equals("-") || getMiddle().equals("~")) {

			parseTerm();
			String op = getMiddle();
			if (op.equals("+") || op.equals("-") || op.equals("*") || op.equals("/") || op.equals("&lt;")
					|| op.equals("|") || op.equals("&amp;") || op.equals("&gt;") || op.equals("=")) {
				add();
			}
		}

		goToParent();

	}

	private void parseTerm() {
		newNode("term");

		if (getFirst().equals("<integerConstant>") || getFirst().equals("<stringConstant>")
				|| getFirst().equals("<keyword>")) {
			add();
		} else if (getFirst().equals("<identifier>")) {

			if (getNextMiddle().equals(".") || getNextMiddle().equals("(")) {
				parseSubroutineCall();
			} else {
				add();
				if (getMiddle().equals("[")) {
					add();
					parseExpression();
					add();
				}
			}

		} else if (getMiddle().equals("(")) {
			add();
			parseExpression();
			add();
		} else if (getMiddle().equals("-") || getMiddle().equals("~")) {
			add();
			if (getFirst().equals("<identifier>") || getFirst().equals("<integerConstant>") || getMiddle().equals("(")) {
				parseTerm();
			}
		}

		goToParent();
	}

	private void parseExpressionList() {
		newNode("expressionList");

		if (!getMiddle().equals(")")) {
			parseExpression();
			while (getMiddle().equals(",")) {
				add();
				parseExpression();
			}
		}

		goToParent();
	}

	private void parseSubroutineCall() {
		add();
		if (getMiddle().equals("(")) {
			add();
			parseExpressionList();
			add();
		} else {
			add();
			add();
			add();
			parseExpressionList();
			add();
		}
	}
}