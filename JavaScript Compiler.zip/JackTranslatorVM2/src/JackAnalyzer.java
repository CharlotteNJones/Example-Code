import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Scanner;

public class JackAnalyzer {
	public static void main(String[] args) throws FileNotFoundException {
		if (args.length == 0) {
			System.err.println("Usage: java Text file.asm");
			System.exit(1);
		}
		String filename = args[0];
		// System.out.println(inputFile);

		// String outputFile = folder + ".xml";
		// System.out.println(outputFile);

		processFile(filename);
	}

	private static void processFile(String filename) throws FileNotFoundException {

		File fin = new File(filename);
		
		File[] fileList = new File[1];
		
		if (filename.contains(".jack")) {
			fileList[0] = fin;
		} else {
			fileList = fin.listFiles();
		}

		for (File f : fileList) {
			ArrayList<String> lines = new ArrayList<>();
			String name = f.getName();

			if (name.contains(".jack")) {
				Scanner s = new Scanner(f);
				System.out.println(name);
				System.out.println(name.replace(".jack", ".vm"));
				while (s.hasNextLine()) {
					String line = s.nextLine();
					lines.add(line);
				}
				s.close();

				JackTokenizer tokenize = new JackTokenizer();
				CompilationEngine comp = new CompilationEngine();
				
				ArrayList<String> tokens = tokenize.translate(lines);
				Node xml = comp.translate(tokens);
				
				VMWriter writer = new VMWriter();
				ArrayList<String> out = writer.writeVM(xml);
				
				File fout;
				
				if (filename.contains(".jack")) {
					fout = new File(name.replace(".jack", ".vm"));
				} else {
					fout = new File(fin, name.replace(".jack", ".vm"));
				}
				PrintStream output = new PrintStream(fout);
				for (String line : out) {
					output.println(line);
				}
				output.close();
			}

		}

	}

}