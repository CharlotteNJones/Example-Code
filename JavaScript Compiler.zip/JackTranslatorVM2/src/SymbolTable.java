import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Map;
import java.util.Set;

class Symbol {
	public String name;
	public String type;
	public VarKind kind;
	public int index;

	public Symbol(String name, String type, VarKind kind, int index) {
		this.name = name;
		this.type = type;
		this.kind = kind;
		this.index = index;
	}
}

public class SymbolTable {
	private Map<String, Symbol> table;
	// private Map<String, Symbol> current;

	public SymbolTable() {
		table = new Hashtable<String, Symbol>();
	}

	public void clear() {
		table.clear();
	}

	public void add(String name, String type, VarKind kind) {
		Symbol sym = new Symbol(name, type, kind, varCount(kind));
		table.put(name, sym);

	}

	public String getPop(String name) {
		Symbol sym = table.get(name);
		return "pop " + sym.kind.toString() + " " + sym.index;
	}

	public String getPush(String name) {
		Symbol sym = table.get(name);
		return "push " + sym.kind.toString() + " " + sym.index;
	}

	public int varCount(VarKind kind) {
		int count = 0;

		Set<String> keys = table.keySet();

		for (String key : keys) {
			if (table.get(key).kind == kind) {
				count++;
			}
		}

		return count;
	}
	
	public String getType(String title) {
		return (table.get(title).type);
	}

	public boolean containsKey(String name) {
		Set<String> keys = table.keySet();
		for (String key : keys) {
			if (name.equals(key)) {
				return true;
			}
		}
		return false;
	}

	public void parseClassVarDec(Node dec) {
		ArrayList<Object> content = dec.getContent();
		String kindString = getMiddle((String) content.get(0));
		VarKind kind;
		if (kindString.equals("field")) {
			kind = VarKind.FIELD;
		} else {
			kind = VarKind.STATIC;
		}
		int namePlace = 2;
		int typePlace = 1;
		String type = getMiddle((String) content.get(typePlace));
		String name;
		
		while (namePlace < content.size()) {
			name = getMiddle((String) content.get(namePlace));
			add(name, type, kind);
			
			namePlace += 2;
		}
		
	}
	
	
	
	
	
	public void parseSubroutineDec(Node sub) {
		ArrayList<Object> content = sub.getContent();

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("subroutineBody")) {
					parseSubroutineBody((Node) item);
				} else if (((Node) item).getType().equals("parameterList")) {
					parseParameterList((Node) item);
				}
			}
		}
	}

	private void parseParameterList(Node parameterList) {
		ArrayList<Object> content = parameterList.getContent();
		String name, type, first, mid;
		int typePlace = 0;
		int namePlace = 1;
		
		while (namePlace < content.size()) {
			type = getMiddle((String) content.get(typePlace));
			name = getMiddle((String) content.get(namePlace));
			add(name, type, VarKind.ARG);
			typePlace += 3;
			namePlace += 3;
		}
		
		/*
		for (Object item : content) {
			if (item instanceof String) {
				first = getFirst((String) item);
				mid = getMiddle((String) item);
				if (first.equals("<keyword>")) {
					type = mid;
				} else if (first.equals("<identifier>")) {
					if (!mid.equals("Array")) {
						name = mid;
						add(name, type, VarKind.ARG);
					}
				}
			}
		}
		*/
	}

	private void parseSubroutineBody(Node subroutineBody) {
		ArrayList<Object> content = subroutineBody.getContent();

		for (Object item : content) {
			if (item instanceof Node) {
				if (((Node) item).getType().equals("varDec")) {
					parseVarDec((Node) item);
				}
			}
		}
	}

	private void parseVarDec(Node varDec) {
		ArrayList<Object> content = varDec.getContent();
		String name, type;
		int typePlace = 1;
		int namePlace = 2;
		
		while (namePlace < content.size()) {
			type = getMiddle((String) content.get(typePlace));
			name = getMiddle((String) content.get(namePlace));
			add(name, type, VarKind.VAR);
			//typePlace += 2;
			namePlace += 2;
		}
		
		/*
		String type = getMiddle((String) content.get(1));
		ArrayList<String> varNames = new ArrayList<String>();

		for (Object item : content) {
			String line = (String) item;
			if (getFirst(line).equals("<identifier>")) {
				if (!getMiddle(line).equals("Array"))
					varNames.add(getMiddle(line));
			}
		}

		for (String name : varNames) {
			add(name, type, VarKind.VAR);
		}
		*/
	}

	private String getMiddle(String line) {
		// System.out.println(tokens.get(currentToken));
		// System.out.println();
		String trimmedLine = line.trim();
		int start, end;
		int current = 0;

		if (!trimmedLine.contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			current++;
		}
		start = current + 1;

		current = trimmedLine.length() - 1;
		while (trimmedLine.charAt(current) != ' ') {
			current--;
		}
		end = current;

		return trimmedLine.substring(start, end);

	}

	private String getFirst(String line) {

		String trimmedLine = line.trim();
		String output = "";
		int current = 0;

		if (!trimmedLine.contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			output += trimmedLine.charAt(current);
			current++;
		}

		return output;
	}
}
