import java.util.ArrayList;

public class Node {
	
	private ArrayList<Object> content;
	private String heading;
	private Node parent;
	
	public Node(String heading, Node parent) {
		this.heading = heading;
		this.parent = parent;
		content = new ArrayList<Object>();
	}
	
	public void add(Object addition) {
		content.add(addition);
	}
	
	public ArrayList<String> getXML() {
		ArrayList<String> output = new ArrayList<>();
		
		output.add("<" + heading + ">");
		
		for (Object item : content) {
			if (item instanceof Node) {
				for (String line : ((Node) item).getXML()) {
					output.add("  " + line);
				}
			} else {
				output.add("  " + item);
			}
		}
		
		output.add("</" + heading + ">");

		return output;
	}
	
	public Node getParent() {
		return parent;
	}
	
	public ArrayList<Object> getContent() {
		return content;
	}
	
	public String getType() {
		return heading;
	}
	
	public int getAmountOf(String mid) {
		int count = 0;
		for (Object item : content) {
			if (item instanceof String) {
				if (getMiddle((String) item).equals(mid)) {
					count++;
				}
			}
		}
		return count;
	}
	
	private String getMiddle(String line) {
		// System.out.println(tokens.get(currentToken));
		// System.out.println();
		String trimmedLine = line.trim();
		int start, end;
		int current = 0;

		if (!trimmedLine.contains(" ")) {
			return trimmedLine;
		}

		while (trimmedLine.charAt(current) != ' ') {
			current++;
		}
		start = current + 1;

		current = trimmedLine.length() - 1;
		while (trimmedLine.charAt(current) != ' ') {
			current--;
		}
		end = current;

		return trimmedLine.substring(start, end);

	}
}
